<?php
$_['heading_title'] = 'My Pets info';
